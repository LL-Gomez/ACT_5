SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol ENUM('cliente','ventas') NOT NULL DEFAULT 'cliente'
);
CREATE TABLE IF NOT EXISTS paquetes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(20) NOT NULL UNIQUE,
  destino VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255) NOT NULL,
  precio DECIMAL(12,2) NOT NULL,
  imagen VARCHAR(100) NULL
);
CREATE TABLE IF NOT EXISTS ventas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  fecha DATETIME NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS venta_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  venta_id INT NOT NULL,
  paquete_id INT NULL,
  destino VARCHAR(80) NOT NULL,
  cantidad INT NOT NULL,
  precio_unit DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE CASCADE
);
INSERT INTO usuarios (nombre,email,password,rol) VALUES
('Jefe de Ventas','jefe@agencia.com','SIN_HASH','ventas');
INSERT INTO paquetes (codigo,destino,descripcion,precio) VALUES
('BRC-001','Bariloche','7 noches con aéreo y desayuno',850000),
('IGZ-002','Cataratas del Iguazú','4 noches con excursiones',520000),
('CAR-003','Alquiler de auto','7 días, kilometraje libre',210000),
('MIA-004','Miami','10 noches todo incluido',2300000);
