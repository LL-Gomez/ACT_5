<?php require 'conexion.php'; requiere('cliente');
$c = $_SESSION['carrito'] ?? [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $a = $_POST['accion'] ?? '';
    if ($a === 'agregar') {
        $id = (int)$_POST['id']; $c[$id] = ($c[$id] ?? 0) + max(1, (int)$_POST['cantidad']);
        aviso('Paquete agregado al carrito.');
    } elseif ($a === 'actualizar') {
        foreach ($_POST['q'] ?? [] as $id => $n) { if ((int)$n > 0) $c[(int)$id] = (int)$n; else unset($c[(int)$id]); }
        aviso('Carrito actualizado.');
    } elseif ($a === 'confirmar' && $c) {
        $conn->begin_transaction();
        $total = 0; $lineas = [];
        foreach ($c as $id => $n) {
            $st = $conn->prepare('SELECT id,destino,precio FROM paquetes WHERE id=?');
            $st->bind_param('i', $id); $st->execute();
            if ($p = $st->get_result()->fetch_assoc()) { $lineas[] = [$p, $n]; $total += $p['precio'] * $n; }
        }
        $st = $conn->prepare('INSERT INTO ventas (usuario_id,fecha,total) VALUES (?,NOW(),?)');
        $st->bind_param('id', $_SESSION['usuario']['id'], $total); $st->execute();
        $vid = $conn->insert_id;
        $st = $conn->prepare('INSERT INTO venta_items (venta_id,paquete_id,destino,cantidad,precio_unit) VALUES (?,?,?,?,?)');
        foreach ($lineas as [$p, $n]) { $st->bind_param('iisid', $vid, $p['id'], $p['destino'], $n, $p['precio']); $st->execute(); }
        $conn->commit();
        unset($_SESSION['carrito']);
        aviso("Compra #$vid confirmada. Total: $" . number_format($total, 2, ',', '.'));
        header('Location: ventas.php'); exit;
    }
    $_SESSION['carrito'] = $c;
    header('Location: carrito.php'); exit;
}
include 'header.php'; ?>
<h2>Carrito de compras</h2>
<?php if (!$c): ?><p>El carrito está vacío.</p><?php else: ?>
<form method="post"><?= csrf() ?><input type="hidden" name="accion" value="actualizar">
<table><tr><th>Paquete</th><th>Cantidad</th><th>Subtotal</th></tr>
<?php $total = 0; foreach ($c as $id => $n):
  $st = $conn->prepare('SELECT destino,precio FROM paquetes WHERE id=?'); $st->bind_param('i', $id); $st->execute();
  if (!($p = $st->get_result()->fetch_assoc())) continue; $total += $p['precio'] * $n; ?>
<tr><td><?= h($p['destino']) ?></td><td><input type="number" name="q[<?= $id ?>]" value="<?= $n ?>" min="0" style="width:60px"></td>
<td>$<?= number_format($p['precio'] * $n, 2, ',', '.') ?></td></tr>
<?php endforeach; ?>
<tr><th colspan="2">Total</th><th>$<?= number_format($total, 2, ',', '.') ?></th></tr></table>
<button>Actualizar cantidades (0 quita el paquete)</button></form>
<form method="post"><?= csrf() ?><input type="hidden" name="accion" value="confirmar"><button>Confirmar compra</button></form>
<?php endif; ?>
