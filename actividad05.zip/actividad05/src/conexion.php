<?php
// Conexión a MySQL (servicio "db" de Docker Compose) y utilidades comunes.
session_start();
$conn = new mysqli('db', 'alumno', 'alumno123', 'turismo');
if ($conn->connect_error) {
    die('Error de conexión: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

// Primer arranque: el script SQL deja al jefe con 'SIN_HASH'; acá se genera su hash (Jefe1234).
$h0 = password_hash('Jefe1234', PASSWORD_DEFAULT);
$st0 = $conn->prepare("UPDATE usuarios SET password=? WHERE password='SIN_HASH'");
$st0->bind_param('s', $h0);
$st0->execute();

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function usuario() { return $_SESSION['usuario'] ?? null; }
function requiere($rol = null) {
    $u = usuario();
    if (!$u) { header('Location: login.php'); exit; }
    if ($rol && $u['rol'] !== $rol) { http_response_code(403); die('Sin permisos'); }
}
function csrf() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}
function csrf_ok() { return hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? ''); }
function aviso($m = null) {
    if ($m !== null) { $_SESSION['aviso'] = $m; return; }
    $a = $_SESSION['aviso'] ?? ''; unset($_SESSION['aviso']); return $a;
}
