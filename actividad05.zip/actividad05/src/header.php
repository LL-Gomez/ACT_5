<?php require_once __DIR__ . '/conexion.php'; $u = usuario(); ?>
<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Portal de Turismo</title>
<style>body{font-family:Arial,sans-serif;max-width:900px;margin:auto;padding:1rem}
nav{background:#0a6;padding:.6rem;margin-bottom:1rem}nav a{color:#fff;margin-right:1rem;text-decoration:none}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:6px;text-align:left}
.card{border:1px solid #ddd;padding:.6rem;margin:.5rem 0}.msg{background:#ffe;border:1px solid #cc8;padding:6px}</style>
</head><body>
<nav><b style="color:#fff;margin-right:1rem">Portal de Turismo</b>
<a href="index.php">Paquetes</a>
<?php if ($u && $u['rol'] === 'ventas'): ?><a href="paquetes.php">Administrar paquetes</a><a href="ventas.php">Ventas</a>
<?php elseif ($u): ?><a href="carrito.php">Carrito</a><a href="ventas.php">Mis compras</a><?php endif; ?>
<?php if ($u): ?><a href="logout.php">Salir (<?= h($u['nombre']) ?>)</a>
<?php else: ?><a href="login.php">Ingresar</a><a href="registro.php">Registrarse</a><?php endif; ?></nav>
<?php if ($m = aviso()): ?><p class="msg"><?= h($m) ?></p><?php endif; ?>
