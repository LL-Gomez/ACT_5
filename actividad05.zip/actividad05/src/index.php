<?php require 'conexion.php';
$r = $conn->query('SELECT * FROM paquetes ORDER BY id DESC');
include 'header.php'; ?>
<h2>Paquetes turísticos</h2>
<?php while ($p = $r->fetch_assoc()): ?>
<div class="card">
  <?php if ($p['imagen']): ?><img src="img/<?= h($p['imagen']) ?>" width="120" alt=""><?php endif; ?>
  <b><?= h($p['destino']) ?></b> (<?= h($p['codigo']) ?>) — <?= h($p['descripcion']) ?><br>
  Precio: $<?= number_format($p['precio'], 2, ',', '.') ?>
  <?php if ($u && $u['rol'] === 'cliente'): ?>
  <form method="post" action="carrito.php" style="display:inline">
    <?= csrf() ?><input type="hidden" name="accion" value="agregar">
    <input type="hidden" name="id" value="<?= $p['id'] ?>">
    <input type="number" name="cantidad" value="1" min="1" style="width:55px"><button>Agregar al carrito</button>
  </form>
  <?php elseif (!$u): ?> <a href="login.php">Ingresá para comprar</a><?php endif; ?>
</div>
<?php endwhile; ?>
