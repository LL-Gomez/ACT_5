<?php require 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $e = strtolower(trim($_POST['email']));
    $st = $conn->prepare('SELECT id,nombre,email,password,rol FROM usuarios WHERE email=?');
    $st->bind_param('s', $e); $st->execute();
    $u = $st->get_result()->fetch_assoc();
    if ($u && password_verify($_POST['password'], $u['password'])) {
        session_regenerate_id(true);
        unset($u['password']); $_SESSION['usuario'] = $u;
        header('Location: ' . ($u['rol'] === 'ventas' ? 'paquetes.php' : 'index.php')); exit;
    }
    aviso('Email o contraseña incorrectos.');
}
include 'header.php'; ?>
<h2>Ingresar</h2>
<form method="post"><?= csrf() ?>
<p><input name="email" type="email" placeholder="Email" required></p>
<p><input name="password" type="password" placeholder="Contraseña" required></p>
<button>Ingresar</button></form>
