<?php require 'conexion.php'; requiere('ventas');
$id = (int)($_GET['id'] ?? 0);
$p = ['codigo' => '', 'destino' => '', 'descripcion' => '', 'precio' => '', 'imagen' => null];
if ($id) {
    $st = $conn->prepare('SELECT * FROM paquetes WHERE id=?'); $st->bind_param('i', $id); $st->execute();
    $p = $st->get_result()->fetch_assoc() ?: die('No existe el paquete');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $img = $p['imagen'];
    if (!empty($_FILES['imagen']['name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            $img = bin2hex(random_bytes(8)) . '.' . $ext;
            move_uploaded_file($_FILES['imagen']['tmp_name'], __DIR__ . '/img/' . $img);
        }
    }
    $precio = (float)$_POST['precio'];
    try {
        if ($id) {
            $st = $conn->prepare('UPDATE paquetes SET codigo=?,destino=?,descripcion=?,precio=?,imagen=? WHERE id=?');
            $st->bind_param('sssdsi', $_POST['codigo'], $_POST['destino'], $_POST['descripcion'], $precio, $img, $id);
        } else {
            $st = $conn->prepare('INSERT INTO paquetes (codigo,destino,descripcion,precio,imagen) VALUES (?,?,?,?,?)');
            $st->bind_param('sssds', $_POST['codigo'], $_POST['destino'], $_POST['descripcion'], $precio, $img);
        }
        $st->execute(); aviso('Paquete guardado.'); header('Location: paquetes.php'); exit;
    } catch (mysqli_sql_exception $x) { aviso('Error: el código ya existe o hay datos inválidos.'); }
}
include 'header.php'; ?>
<h2><?= $id ? 'Modificar' : 'Nuevo' ?> paquete</h2>
<form method="post" enctype="multipart/form-data"><?= csrf() ?>
<p><input name="codigo" placeholder="Código" value="<?= h($p['codigo']) ?>" required></p>
<p><input name="destino" placeholder="Destino" value="<?= h($p['destino']) ?>" required></p>
<p><input name="descripcion" placeholder="Descripción" size="50" value="<?= h($p['descripcion']) ?>" required></p>
<p><input name="precio" type="number" step="0.01" min="0" placeholder="Precio" value="<?= h($p['precio']) ?>" required></p>
<p>Foto: <input type="file" name="imagen" accept="image/*"></p>
<button>Guardar</button> <a href="paquetes.php">Cancelar</a></form>
