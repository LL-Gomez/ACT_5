<?php require 'conexion.php'; requiere('ventas');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok() && ($_POST['accion'] ?? '') === 'eliminar') {
    $id = (int)$_POST['id'];
    $st = $conn->prepare('DELETE FROM paquetes WHERE id=?'); $st->bind_param('i', $id); $st->execute();
    aviso('Paquete eliminado.'); header('Location: paquetes.php'); exit;
}
$r = $conn->query('SELECT * FROM paquetes ORDER BY id');
include 'header.php'; ?>
<h2>Administrar paquetes</h2>
<p><a href="paquete_form.php">+ Nuevo paquete</a></p>
<table><tr><th>Código</th><th>Destino</th><th>Descripción</th><th>Precio</th><th></th></tr>
<?php while ($p = $r->fetch_assoc()): ?>
<tr><td><?= h($p['codigo']) ?></td><td><?= h($p['destino']) ?></td><td><?= h($p['descripcion']) ?></td>
<td>$<?= number_format($p['precio'], 2, ',', '.') ?></td>
<td><a href="paquete_form.php?id=<?= $p['id'] ?>">Editar</a>
<form method="post" style="display:inline" onsubmit="return confirm('¿Eliminar?')"><?= csrf() ?>
<input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button>Eliminar</button></form></td></tr>
<?php endwhile; ?></table>
