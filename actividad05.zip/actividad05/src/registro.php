<?php require 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_ok()) {
    $n = trim($_POST['nombre']); $e = strtolower(trim($_POST['email'])); $p = $_POST['password'];
    if (strlen($p) < 6 || !filter_var($e, FILTER_VALIDATE_EMAIL) || $n === '') {
        aviso('Datos inválidos (contraseña mínima: 6 caracteres).');
    } else {
        $hash = password_hash($p, PASSWORD_DEFAULT);
        $st = $conn->prepare("INSERT INTO usuarios (nombre,email,password) VALUES (?,?,?)");
        $st->bind_param('sss', $n, $e, $hash);
        try { $st->execute(); aviso('Cuenta creada. Ya podés ingresar.'); header('Location: login.php'); exit; }
        catch (mysqli_sql_exception $x) { aviso('Ese email ya está registrado.'); }
    }
}
include 'header.php'; ?>
<h2>Alta de cliente</h2>
<form method="post"><?= csrf() ?>
<p><input name="nombre" placeholder="Nombre completo" required></p>
<p><input name="email" type="email" placeholder="Email" required></p>
<p><input name="password" type="password" placeholder="Contraseña (mín. 6)" required></p>
<button>Crear cuenta</button></form>
