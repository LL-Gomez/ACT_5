<?php require 'conexion.php'; requiere();
$u = usuario();
if ($u['rol'] === 'ventas') {
    $r = $conn->query('SELECT v.*, u.nombre FROM ventas v JOIN usuarios u ON u.id=v.usuario_id ORDER BY v.id DESC');
} else {
    $st = $conn->prepare('SELECT v.*, u.nombre FROM ventas v JOIN usuarios u ON u.id=v.usuario_id WHERE v.usuario_id=? ORDER BY v.id DESC');
    $st->bind_param('i', $u['id']); $st->execute(); $r = $st->get_result();
}
include 'header.php'; ?>
<h2><?= $u['rol'] === 'ventas' ? 'Ventas registradas' : 'Mis compras' ?></h2>
<?php while ($v = $r->fetch_assoc()): ?>
<div class="card"><b>Venta #<?= $v['id'] ?></b> · <?= h($v['fecha']) ?> · <?= h($v['nombre']) ?> · Total $<?= number_format($v['total'], 2, ',', '.') ?>
<ul><?php $it = $conn->query('SELECT * FROM venta_items WHERE venta_id=' . (int)$v['id']);
while ($i = $it->fetch_assoc()): ?><li><?= (int)$i['cantidad'] ?> × <?= h($i['destino']) ?> ($<?= number_format($i['precio_unit'], 2, ',', '.') ?>)</li><?php endwhile; ?></ul></div>
<?php else: ?><p>No hay ventas.</p><?php endwhile; ?>
